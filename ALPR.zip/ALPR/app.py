from PIL import Image
import streamlit as st

# Set page title and icon
st.set_page_config(page_title="ALPR Application", page_icon="🚗")

# Set background color and padding
st.markdown(
    """
    <style>
        body {
            background-color: #f0f0f0;
            padding: 2rem;
            text-align: center;
        }
        .title {
            color: #1f78b4;
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        .introduction {
            color: #333;
            font-size: 1.2rem;
        }
    </style>
    """,
    unsafe_allow_html=True,
)

# Title and introduction
st.markdown('<p class="title">Research and Implementation of Automatic License Plate Recognition (ALPR)</p>', unsafe_allow_html=True)
st.markdown('<p class="introduction">Welcome to the Automatic License Plate Recognition Web Application</p>', unsafe_allow_html=True)

# Personal Information Section
st.header("Personal Information")
st.write("Name: SARKER MASFIQUE HASAN")
st.write("Passport: A05577719")
st.write("Country: Bangladesh")
st.write("Education: Bachelor in Electrical and Electronics Engineering")
st.write("University Name: Shanghai University of Engineering Science")
st.write("Major: Artificial Intelligence")
st.write("Thesis Title: Research and Implementation of Automatic License Plate Recognition")


# Footer
st.markdown(
    """
    <hr>
    <p style="text-align: center; color: #808080;">Developed by SARKER MASFIQUE HASAN | 2024</p>
    """,
    unsafe_allow_html=True,
)
